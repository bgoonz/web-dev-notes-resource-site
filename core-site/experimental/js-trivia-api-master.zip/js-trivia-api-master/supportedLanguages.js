module.exports = ["en", "es", "fr", "de", "ja", "ru", "pt-br", "zh-cn", "id", "ko"]
