import React from 'react';
import ReactDOM from 'react-dom';
import Calculator from './Calculator';

ReactDOM.render(
  <Calculator />,
  document.getElementById('wrapper')
);
