Check composition of:
- Calculator Component, created by @mjackson (https://github.com/mjackson).
   - The code: http://codepen.io/anon/pen/PzdbmX
- Create React App, developed by Facebook
   - The app: https://facebook.github.io/react/blog/2016/07/22/create-apps-with-no-configuration.html
